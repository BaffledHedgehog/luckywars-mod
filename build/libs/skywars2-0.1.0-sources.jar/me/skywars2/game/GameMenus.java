package me.skywars2.game;

import eu.pb4.sgui.api.elements.GuiElementBuilder;
import eu.pb4.sgui.api.gui.SimpleGui;

import net.minecraft.network.chat.Component;
import net.minecraft.core.component.DataComponents;
import net.minecraft.ChatFormatting;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.List;
import java.util.UUID;

/** All player-facing lobby menus, kept together so navigation and actions share one contract. */
public final class GameMenus {
    private static final int PAGE_SIZE = 28;
    private static final String[] STAGE_ONE_EVENTS = {
        "speed", "haste", "refill", "jump", "health", "center_chests", "invisibility", "glowing"
    };
    private static final String[] STAGE_TWO_EVENTS = {
        "wither",
        "dragon",
        "wither_again",
        "tnt_rain",
        "border_shrink",
        "levitation",
        "chest_minecarts"
    };
    private static final String[] ORIGINAL_KIT_IDS = {
        "a1", "a2", "a3", "a4", "a5", "a6", "a7",
        "b1", "b2", "b3", "b4", "b5",
        "c1", "c2", "c3", "c4", "c5", "d1",
        null, "d2", "d3", null, null, null
    };
    private static final String[] ORIGINAL_KIT_NAME_KEYS = {
        "swrg.kit.a1", "swrg.kit.a2", "swrg.kit.a3", "swrg.kit.a4", "swrg.kit.a5", "swrg.kit.a6", "swrg.kit.a7",
        "swrg.kit.b1", "swrg.kit.b2", "swrg.kit.b3", "swrg.kit.b4", "swrg.kit.b5",
        "swrg.kit.c1", "swrg.kit.c2", "swrg.kit.c3", "swrg.kit.c4", "swrg.kit.c5", "swrg.kit.d1",
        null, "swrg.kit.d2", "swrg.kit.d3", "golden_pumpkin", "mace", "wind_charge"
    };
    private static final String[] ORIGINAL_SKILL_KEYS = {
        "swrg.skill.a1", "swrg.skill.a2", "swrg.skill.a3", "swrg.skill.a4",
        "swrg.skill.b1", "swrg.skill.b2", "swrg.skill.b3", "swrg.skill.c1",
        "swrg.skill.c2", "swrg.skill.d1", "swrg.skill.d2", "wind_runner_skill", "dualist_skill"
    };
    private static final String[] ORIGINAL_SKILL_LORE_KEYS = {
        "swrg.lore.skill.a1.0", "swrg.lore.skill.a2.0", "swrg.lore.skill.a3.0", "swrg.lore.skill.a4.0",
        "swrg.lore.skill.b1.0", "swrg.lore.skill.b2.0", "swrg.lore.skill.b3.0", "swrg.lore.skill.c1.0",
        "swrg.lore.skill.c2.0", "swrg.lore.skill.d1.0", "swrg.lore.skill.d2.0",
        "wind_runner_skill.lore.1", "dualist_skill.lore"
    };
    private final MinecraftServer server;
    private final GameController controller;
    private final GameConfig config;
    private final PlayerStore players;
    private final MapManager maps;
    private final java.util.Map<UUID, Integer> mapPages = new java.util.HashMap<>();

    public GameMenus(
            MinecraftServer server,
            GameController controller,
            GameConfig config,
            PlayerStore players,
            MapManager maps) {
        this.server = server;
        this.controller = controller;
        this.config = config;
        this.players = players;
        this.maps = maps;
    }

    private static Component t(String key, Object... args) {
        return Component.translatable("skywars2.gui." + key, args);
    }

    private static Component c(String key, Object... args) {
        return Component.translatable("skywars2.common." + key, args);
    }

    public void open(ServerPlayer player) {
        open(player, Page.HUB);
    }

    public void open(ServerPlayer player, Page page) {
        if (!controller.canUseMenus() && page != Page.STATS) {
            player.sendSystemMessage(c("lobby_only"));
            return;
        }
        PlayerStore.Profile profile = players.get(player.getUUID(), player.getName().getString());
        Menu gui = new Menu(player, page);
        gui.setTitle(title(page, player));
        gui.setLockPlayerInventory(true);
        switch (page) {
            case HUB -> renderHub(gui, player, profile);
            case SETTINGS -> renderSettings(gui, player);
            case MAPS -> renderMaps(gui, player);
            case VANILLA_KITS -> renderKits(gui, player, profile);
            case VANILLA_SKILLS -> renderSkills(gui, player, profile);
            case KEY_SHOP -> renderKeyShop(gui, player, profile);
            case STATS -> renderStats(gui, player, profile);
            case LBC_KITS, LBC_SKILLS, LBC_TRINKETS, LBC_LEVELUPS, LBC_CHALLENGE ->
                    renderLbc(gui, player, profile);
            case COSMETICS -> renderCosmetics(gui, player, profile);
            case CASES -> renderCases(gui);
            case BEDWARS -> renderUnsupported(gui, "bedwars.title", "bedwars.boundary");
        }
        gui.open();
    }

    private void renderHub(Menu gui, ServerPlayer player, PlayerStore.Profile p) {
        put(gui, 4, Items.COMPASS, t("hub.title"), t("hub.status", controller.status()), null);
        put(
                gui,
                10,
                Items.NETHER_STAR,
                legacyName("swrg.page0.s1", ChatFormatting.GREEN),
                controller.canStart(player) ? t("hub.quick.ready") : t("hub.quick.check"),
                () -> controller.requestStart(player, true));
        putOriginalName(
                gui,
                11,
                Items.MAP,
                legacyName("swrg.page0.s2", ChatFormatting.AQUA),
                List.of(t("hub.maps.selected", config.mapId)),
                () -> open(player, Page.MAPS));
        putOriginalName(
                gui,
                12,
                Items.REPEATER,
                legacyName("swrg.page0.s0", ChatFormatting.RED),
                List.of(t("hub.settings.lore")),
                () -> open(player, Page.SETTINGS));
        putOriginalName(
                gui,
                13,
                Items.IRON_SWORD,
                legacyName("swrg.page0.s12", ChatFormatting.GOLD),
                List.of(selectedLabel(selected(p.kit))),
                () -> open(player, Page.VANILLA_KITS));
        putOriginalName(
                gui,
                14,
                Items.POTION,
                legacyName("swrg.page0.s14", ChatFormatting.AQUA),
                List.of(selectedLabel(selected(p.skill))),
                () -> open(player, Page.VANILLA_SKILLS));
        putOriginalName(
                gui,
                15,
                Items.GOLD_INGOT,
                legacyName("swrg.page0.s6", ChatFormatting.YELLOW),
                List.of(balance(p.coins, p.memcoins)),
                () -> open(player, Page.KEY_SHOP));
        putOriginalName(
                gui,
                16,
                Items.CHEST,
                legacyName("swrg.page0.s13", ChatFormatting.LIGHT_PURPLE),
                List.of(t("cases.boundary.short")),
                () -> open(player, Page.CASES));
        putOriginalName(
                gui,
                19,
                Items.BOOK,
                legacyName("swrg.page0.s22", ChatFormatting.WHITE),
                List.of(t("lbc.kits.short")),
                () -> open(player, Page.LBC_KITS));
        putOriginalName(
                gui,
                20,
                Items.FEATHER,
                legacyName("swrg.page0.s23", ChatFormatting.WHITE),
                List.of(t("lbc.skills.short")),
                () -> open(player, Page.LBC_SKILLS));
        put(
                gui,
                21,
                Items.AMETHYST_SHARD,
                t("lbc.trinkets"),
                t("lbc.trinkets.short"),
                () -> open(player, Page.LBC_TRINKETS));
        put(
                gui,
                22,
                Items.EXPERIENCE_BOTTLE,
                t("lbc.levelups"),
                t("lbc.levelups.short"),
                () -> open(player, Page.LBC_LEVELUPS));
        putOriginalName(
                gui,
                23,
                Items.TARGET,
                legacyName("swrg.page0.s24", ChatFormatting.WHITE),
                List.of(t("lbc.challenge.short")),
                () -> open(player, Page.LBC_CHALLENGE));
        put(
                gui,
                24,
                Items.FIREWORK_STAR,
                legacyName("swrg.page0.s7", ChatFormatting.YELLOW),
                t("cosmetics.short"),
                () -> open(player, Page.COSMETICS));
        put(
                gui,
                25,
                Items.PLAYER_HEAD,
                legacyName("swrg.stat.profile", ChatFormatting.GREEN),
                t("hub.stats", p.games, p.wins),
                () -> open(player, Page.STATS));
        put(
                gui,
                26,
                Items.SHIELD,
                t("bedwars.title"),
                t("bedwars.boundary.short"),
                () -> open(player, Page.BEDWARS));
    }

    private void renderSettings(Menu gui, ServerPlayer p) {
        put(
                gui,
                10,
                Items.TOTEM_OF_UNDYING,
                t("settings.lives", config.lives),
                t("settings.click"),
                () -> change(p, () -> config.lives = cycle(config.lives, 1, 5)));
        put(
                gui,
                11,
                Items.GOLDEN_APPLE,
                t("settings.health", config.health),
                t("settings.range", 20),
                () -> change(p, () -> config.health = cycle(config.health, 1, 20)));
        put(
                gui,
                12,
                Items.CLOCK,
                t("settings.countdown", config.countdownSeconds),
                t("settings.countdown.lore"),
                () ->
                        change(
                                p,
                                () ->
                                        config.countdownSeconds =
                                                cycle(config.countdownSeconds, 0, 60)));
        put(
                gui,
                13,
                Items.CLOCK,
                t("settings.stage_one", config.stageOneSeconds),
                t("settings.range", 3600),
                () ->
                        change(
                                p,
                                () ->
                                        config.stageOneSeconds =
                                                cycle(config.stageOneSeconds, 0, 3600)));
        put(
                gui,
                14,
                Items.CLOCK,
                t("settings.stage_two", config.stageTwoSeconds),
                t("settings.range", 7200),
                () ->
                        change(
                                p,
                                () ->
                                        config.stageTwoSeconds =
                                                cycle(config.stageTwoSeconds, 0, 7200)));
        put(
                gui,
                15,
                Items.CLOCK,
                t("settings.ending", config.endingSeconds),
                t("settings.range", 120),
                () -> change(p, () -> config.endingSeconds = cycle(config.endingSeconds, 0, 120)));
        put(
                gui,
                16,
                Items.IRON_SWORD,
                t("settings.pvp", config.pvpMode),
                t("settings.pvp.lore"),
                () -> change(p, () -> config.pvpMode = cycle(config.pvpMode, 1, 2)));
        put(
                gui,
                19,
                Items.SUNFLOWER,
                t("settings.day", config.day),
                t("settings.day.lore"),
                () -> change(p, () -> config.day = cycle(config.day, 1, 3)));
        put(
                gui,
                20,
                Items.CHEST,
                t("settings.vanilla_kits", yesNo(config.vanillaKits)),
                t("settings.kits.lore"),
                () -> change(p, () -> config.vanillaKits = !config.vanillaKits));
        put(
                gui,
                21,
                Items.FEATHER,
                t("settings.vanilla_skills", yesNo(config.vanillaSkills)),
                t("settings.skills.lore"),
                () -> change(p, () -> config.vanillaSkills = !config.vanillaSkills));
        put(
                gui,
                22,
                Items.BARRIER,
                t("settings.no_borders", yesNo(config.noBorders)),
                t("settings.toggle"),
                () -> change(p, () -> config.noBorders = !config.noBorders));
        put(
                gui,
                23,
                Items.RECOVERY_COMPASS,
                t(
                        "settings.stage_one_event",
                        eventSelection(config.stageOneEvent, STAGE_ONE_EVENTS)),
                t("settings.event_one.lore"),
                () -> change(p, () -> config.stageOneEvent = cycle(config.stageOneEvent, 0, 9)));
        put(
                gui,
                24,
                Items.RECOVERY_COMPASS,
                t(
                        "settings.stage_two_event",
                        eventSelection(config.stageTwoEvent, STAGE_TWO_EVENTS)),
                t("settings.event_two.lore"),
                () -> change(p, () -> config.stageTwoEvent = cycle(config.stageTwoEvent, 0, 8)));
        putOriginalName(
                gui,
                25,
                Items.STRUCTURE_VOID,
                legacyName("swrg.page1000.s26", ChatFormatting.GREEN),
                List.of(t("settings.reset.lore")),
                () -> {
                    if (!controller.inLobby()) {
                        p.sendSystemMessage(c("lobby_only"));
                        return;
                    }
                    copyConfig(GameConfig.resetDefaults(), config);
                    open(p, Page.SETTINGS);
                });
        back(gui, 49, p, Page.HUB);
    }

    private void renderMaps(Menu gui, ServerPlayer player) {
        List<MapManager.MapInfo> catalog = maps.catalog();
        int pages = Math.max(1, (catalog.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        int page = Math.max(0, Math.min(mapPages.getOrDefault(player.getUUID(), 0), pages - 1));
        mapPages.put(player.getUUID(), page);
        int start = page * PAGE_SIZE;
        for (int i = 0; i < PAGE_SIZE && start + i < catalog.size(); i++) {
            MapManager.MapInfo map = catalog.get(start + i);
            int slot = 10 + i % 7 + i / 7 * 9;
            boolean selected = map.id().equals(config.mapId);
            Component mapName =
                    t("maps.name", map.displayName(), map.id()).copy()
                            .withStyle(style -> style.withItalic(false));
            Component lore =
                    map.available()
                            ? t(
                                    "maps.details",
                                    map.playerCapacity(),
                                    selected
                                            ? Component.translatable("swrg.gui.select")
                                                    .withStyle(style -> style.withColor(ChatFormatting.GREEN).withItalic(false))
                                            : t("maps.not_selected"))
                            : t("maps.unavailable", map.unavailableReason());
            Runnable selectMap =
                    map.available()
                            ? () -> {
                                MapManager.MapInfo current = maps.info(map.id());
                                if (current == null || !current.available()) {
                                    player.sendSystemMessage(t("maps.now_unavailable"));
                                    return;
                                }
                                if (current.playerCapacity() > 0
                                        && server.getPlayerList().getPlayers().size()
                                                > current.playerCapacity()) {
                                    player.sendSystemMessage(t("maps.capacity"));
                                    return;
                                }
                                if (controller.selectMap(player, map.id(), config.broken)) {
                                    config.mapId = map.id();
                                    config.save();
                                    open(player, Page.MAPS);
                                }
                            }
                            : null;
            if (map.available())
                putOriginal(gui, slot, Items.MAP, mapName, List.of(lore), false, selectMap);
            else put(gui, slot, Items.BARRIER, mapName, lore, null);
        }
        putOriginalName(
                gui,
                45,
                Items.ARROW,
                legacyName("swrg.gui.back", ChatFormatting.RED),
                List.of(c("back.lore")),
                () -> open(player, Page.HUB));
        if (page > 0)
            putOriginalName(
                    gui,
                    48,
                    Items.SPECTRAL_ARROW,
                    legacyName("swrg.gui.previous", ChatFormatting.RED),
                    List.of(t("maps.page", page + 1, pages)),
                    () -> {
                        mapPages.put(player.getUUID(), page - 1);
                        open(player, Page.MAPS);
                    });
        putOriginalName(
                gui,
                49,
                Items.PAPER,
                legacyName("swrg.page0.s2", ChatFormatting.AQUA),
                List.of(t("maps.page", page + 1, pages)),
                null);
        if (page + 1 < pages)
            putOriginalName(
                    gui,
                    50,
                    Items.SPECTRAL_ARROW,
                    legacyName("swrg.gui.next", ChatFormatting.RED),
                    List.of(t("maps.page", page + 1, pages)),
                    () -> {
                        mapPages.put(player.getUUID(), page + 1);
                        open(player, Page.MAPS);
                    });
        put(
                gui,
                52,
                config.broken ? Items.CRACKED_STONE_BRICKS : Items.STONE_BRICKS,
                t("maps.broken", yesNo(config.broken)),
                config.broken ? t("maps.broken.lore") : t("maps.full.lore"),
                () -> {
                    boolean selected = !config.broken;
                    if (controller.selectMap(player, config.mapId, selected)) {
                        config.broken = selected;
                        config.save();
                        open(player, Page.MAPS);
                    }
                });
    }

    private void renderKits(Menu gui, ServerPlayer player, PlayerStore.Profile p) {
        put(gui, 4, Items.BARRIER, t("kits.unlocks.title"), t("kits.unlocks.lore"), null);
        String[] kitKeys = {
            "tnt",
            "wolf",
            "potions",
            "wood_sword",
            "food",
            "chain_thorns",
            "gold_protection",
            "poison",
            "gilded",
            "shield",
            "enchanting",
            "poison_potions",
            "gold_tools",
            "crossbow",
            "invisibility",
            "fire_lava",
            "cake_slime",
            "special_mage",
            "empty",
            "golden",
            "oak_slab",
            "halloween",
            "wind_burst",
            "wind_charge"
        };
        for (int id = 1; id <= 24; id++) {
            int kit = id, slot = 9 + (id - 1) % 8 + (id - 1) / 8 * 9;
            String unlock =
                    id == 19
                            ? "kits.unlock.none"
                            : id >= 22 ? "kits.unlock.advancement" : "kits.unlock.tag";
            String originalId = ORIGINAL_KIT_IDS[id - 1];
            String originalNameKey = ORIGINAL_KIT_NAME_KEYS[id - 1];
            Component name =
                    originalNameKey == null
                            ? t("kits.name", id)
                            : legacyName(
                                    originalNameKey,
                                    originalId == null ? ChatFormatting.WHITE : kitColor(originalId));
            List<Component> lore =
                    originalNameKey == null
                            ? List.of(t("kits.item." + kitKeys[id - 1], t(unlock), yesNo(id == p.kit)))
                            : originalId == null
                                    ? originalKitLore(specialKitLoreKeys(id))
                                    : originalKitLore(originalKitLoreKeys(originalId));
            Item item = id == p.kit ? Items.ENCHANTED_BOOK : Items.BARRIER;
            if (originalNameKey == null) put(gui, slot, item, name, lore, null);
            else putOriginal(gui, slot, item, name, lore, null);
        }
        put(
                gui,
                48,
                Items.BARRIER,
                t("kits.none"),
                t("selection.clear"),
                () -> {
                    p.kit = 0;
                    players.save();
                    open(player, Page.VANILLA_KITS);
                });
        back(gui, 49, player, Page.HUB);
    }

    private void renderSkills(Menu gui, ServerPlayer player, PlayerStore.Profile p) {
        put(gui, 4, Items.BARRIER, t("skills.unlocks.title"), t("skills.unlocks.lore"), null);
        String[] names = {
            "spider",
            "heavy",
            "runner",
            "omnivore",
            "berserker",
            "archer",
            "fury",
            "phoenix",
            "maniac",
            "thunderer",
            "vampire",
            "wind_wings",
            "vex"
        };
        for (int i = 0; i < names.length; i++) {
            int skill = i + 1;
            Item item = skill == p.skill ? Items.ENCHANTED_BOOK : Items.BARRIER;
            Component name =
                    ORIGINAL_SKILL_KEYS[i] == null
                            ? t("skills.name." + names[i])
                            : legacyName(ORIGINAL_SKILL_KEYS[i], skillColor(i));
            Component originalLore =
                    Component.translatable(ORIGINAL_SKILL_LORE_KEYS[i])
                            .withStyle(style -> style.withColor(ChatFormatting.GRAY).withItalic(false));
            putOriginal(gui, 10 + i, item, name, List.of(originalLore), null);
        }
        put(
                gui,
                48,
                Items.BARRIER,
                t("skills.none"),
                t("selection.clear"),
                () -> {
                    p.skill = 0;
                    players.save();
                    open(player, Page.VANILLA_SKILLS);
                });
        back(gui, 49, player, Page.HUB);
    }

    private void renderKeyShop(Menu gui, ServerPlayer player, PlayerStore.Profile p) {
        putOriginalName(
                gui,
                4,
                Items.GOLD_INGOT,
                legacyName("swrg.gui.balance", ChatFormatting.WHITE),
                List.of(t("shop.balance", p.coins, p.memcoins)),
                null);
        int[][] costs = {
            {100, 400, 700}, {150, 600, 1050}, {150, 600, 1050}, {200, 800, 1400}, {100, 400, 750}
        };
        for (int key = 0; key < 5; key++)
            for (int tier = 0; tier < 3; tier++) {
                int k = key,
                        amount = tier == 0 ? 1 : tier == 1 ? 5 : 10,
                        price = costs[key][tier],
                        slot = 10 + key * 8 + tier;
                boolean mem = key == 4;
            putRawLore(
                        gui,
                        slot,
                        Items.TRIPWIRE_HOOK,
                        t("shop.key", key + 1, amount),
                        t(
                                "shop.price",
                                price,
                                Component.translatable(mem ? "swrg.gui.memcoins" : "swrg.gui.coins"),
                                mem ? p.memcoins : p.coins),
                        () -> {
                            int current = mem ? p.memcoins : p.coins;
                            if (current < price) {
                                player.sendSystemMessage(c("insufficient_funds"));
                                return;
                            }
                            if (mem) p.memcoins -= price;
                            else p.coins -= price;
                            p.keys[k] += amount;
                            players.save();
                            open(player, Page.KEY_SHOP);
                        });
            }
        back(gui, 49, player, Page.HUB);
    }

    private void renderStats(Menu gui, ServerPlayer player, PlayerStore.Profile p) {
        putOriginalName(
                gui,
                20,
                Items.PLAYER_HEAD,
                Component.translatable("swrg.stat.profile")
                        .withStyle(style -> style.withColor(ChatFormatting.GREEN).withItalic(false))
                        .append(Component.literal(p.username)),
                List.of(t("stats.uuid", player.getUUID().toString())),
                null);
        putRawLore(
                gui,
                22,
                Items.WRITABLE_BOOK,
                Component.translatable("swrg.stat.game_played")
                        .withStyle(style -> style.withColor(ChatFormatting.GREEN).withItalic(false))
                        .append(Component.literal(Integer.toString(p.games))),
                List.of(t("stats.wins_kills", p.wins, p.kills)),
                null);
        putRawLore(
                gui,
                24,
                Items.SKELETON_SKULL,
                t("stats.deaths", p.deaths),
                Component.translatable("swrg.gui.keys")
                        .append(Component.literal(": "))
                        .append(join(p.keys))
                        .withStyle(style -> style.withColor(ChatFormatting.WHITE).withItalic(false)),
                null);
        back(gui, 49, player, Page.HUB);
    }

    private void renderLbc(Menu gui, ServerPlayer player, PlayerStore.Profile p) {
        int value =
                switch (gui.page) {
                    case LBC_KITS -> p.lbcKit;
                    case LBC_SKILLS -> p.lbcSkill;
                    case LBC_TRINKETS -> p.lbcTrinket;
                    case LBC_CHALLENGE -> p.lbcChallenge;
                    default -> 0;
                };
        Component categoryTitle = lbcCategoryTitle(gui.page);
        Component boundary = t("lbc.boundary");
        if (gui.page == Page.LBC_LEVELUPS) {
            for (int i = 0; i < p.levelups.length; i++) {
                int ix = i;
                put(
                        gui,
                        20 + i,
                        Items.EXPERIENCE_BOTTLE,
                        t("lbc.levelup", i + 1, p.levelups[i]),
                        boundary,
                        () -> {
                            p.levelups[ix] = next(p.levelups[ix], 0, 24);
                            players.save();
                            open(player, gui.page);
                        });
            }
        } else {
            putOriginalName(gui, 22, Items.BOOK, categoryTitle, List.of(boundary), null);
            put(
                    gui,
                    30,
                    Items.ARROW,
                    t("lbc.next"),
                    t("lbc.next.lore"),
                    () -> {
                        switch (gui.page) {
                            case LBC_KITS -> p.lbcKit = next(p.lbcKit, 0, 24);
                            case LBC_SKILLS -> p.lbcSkill = next(p.lbcSkill, 0, 24);
                            case LBC_TRINKETS -> p.lbcTrinket = next(p.lbcTrinket, 0, 12);
                            case LBC_CHALLENGE -> p.lbcChallenge = next(p.lbcChallenge, 0, 24);
                            default -> {}
                        }
                        players.save();
                        open(player, gui.page);
                    });
        }
        putOriginalName(
                gui,
                48,
                Items.BARRIER,
                legacyName("swrg.gui.reset", ChatFormatting.RED),
                List.of(t("selection.zero")),
                () -> {
                    switch (gui.page) {
                        case LBC_KITS -> p.lbcKit = 0;
                        case LBC_SKILLS -> p.lbcSkill = 0;
                        case LBC_TRINKETS -> p.lbcTrinket = 0;
                        case LBC_CHALLENGE -> p.lbcChallenge = 0;
                        case LBC_LEVELUPS -> java.util.Arrays.fill(p.levelups, 0);
                        default -> {}
                    }
                    players.save();
                    open(player, gui.page);
                });
        back(gui, 49, player, Page.HUB);
    }

    private void renderCosmetics(Menu gui, ServerPlayer player, PlayerStore.Profile p) {
        String[] names = {
            "cosmetics.kill_sound", "cosmetics.suffix", "cosmetics.win_effect", "cosmetics.cage"
        };
        int[] values = {p.killSound, p.suffix, p.winEffect, p.cage};
        for (int i = 0; i < names.length; i++)
            put(
                    gui,
                    20 + i,
                    Items.FIREWORK_STAR,
                    t(names[i], values[i]),
                    t("cosmetics.boundary"),
                    null);
        back(gui, 49, player, Page.HUB);
    }

    private void renderCases(Menu gui) {
        putOriginalName(
                gui,
                22,
                Items.BARRIER,
                legacyName("swrg.page0.s13", ChatFormatting.LIGHT_PURPLE),
                List.of(t("cases.boundary")),
                null);
    }

    private void renderUnsupported(Menu gui, String title, String explanation) {
        put(gui, 22, Items.BARRIER, t(title), t(explanation), null);
    }

    private void change(ServerPlayer player, Runnable mutation) {
        if (!controller.inLobby()) {
            player.sendSystemMessage(c("lobby_only"));
            return;
        }
        mutation.run();
        config.save();
        open(player, Page.SETTINGS);
    }

    private void put(
            Menu gui, int slot, Item item, Component name, Component lore, Runnable click) {
        put(gui, slot, item, name, lore, false, click);
    }

    private void put(
            Menu gui,
            int slot,
            Item item,
            Component name,
            Component lore,
            boolean allowOutsideLobby,
            Runnable click) {
        put(gui, slot, item, name, List.of(lore), allowOutsideLobby, click);
    }

    private void put(
            Menu gui,
            int slot,
            Item item,
            Component name,
            List<Component> lore,
            boolean allowOutsideLobby,
            Runnable click) {
        GuiElementBuilder builder = new GuiElementBuilder(item).setName(name).setLore(lore);
        if (click != null)
            builder.setCallback(
                    (index, type, action, source) -> {
                        if (!controller.canUseMenus() && gui.page != Page.STATS && !allowOutsideLobby) {
                            gui.getPlayer().sendSystemMessage(c("lobby_only"));
                            return;
                        }
                        click.run();
                    });
        gui.setSlot(slot, builder.build());
    }

    private void put(
            Menu gui, int slot, Item item, Component name, List<Component> lore, Runnable click) {
        put(gui, slot, item, name, lore, false, click);
    }

    private void putOriginal(
            Menu gui, int slot, Item item, Component name, List<Component> lore, Runnable click) {
        putOriginal(gui, slot, item, name, lore, false, click);
    }

    private void putOriginal(
            Menu gui,
            int slot,
            Item item,
            Component name,
            List<Component> lore,
            boolean allowOutsideLobby,
            Runnable click) {
        GuiElementBuilder builder =
                new GuiElementBuilder(item)
                        .setComponent(DataComponents.CUSTOM_NAME, name)
                        .setLoreRaw(lore);
        if (click != null)
            builder.setCallback(
                    (index, type, action, source) -> {
                        if (!controller.canUseMenus() && gui.page != Page.STATS && !allowOutsideLobby) {
                            gui.getPlayer().sendSystemMessage(c("lobby_only"));
                            return;
                        }
                        click.run();
                    });
        gui.setSlot(slot, builder.build());
    }

    private void putOriginalName(
            Menu gui, int slot, Item item, Component name, List<Component> lore, Runnable click) {
        putOriginalName(gui, slot, item, name, lore, false, click);
    }

    private void putOriginalName(
            Menu gui,
            int slot,
            Item item,
            Component name,
            List<Component> lore,
            boolean allowOutsideLobby,
            Runnable click) {
        GuiElementBuilder builder =
                new GuiElementBuilder(item)
                        .setComponent(DataComponents.CUSTOM_NAME, name)
                        .setLore(lore);
        if (click != null)
            builder.setCallback(
                    (index, type, action, source) -> {
                        if (!controller.canUseMenus() && gui.page != Page.STATS && !allowOutsideLobby) {
                            gui.getPlayer().sendSystemMessage(c("lobby_only"));
                            return;
                        }
                        click.run();
                    });
        gui.setSlot(slot, builder.build());
    }

    private void putRawLore(
            Menu gui,
            int slot,
            Item item,
            Component name,
            Component lore,
            Runnable click) {
        putRawLore(gui, slot, item, name, List.of(lore), click);
    }

    private void putRawLore(
            Menu gui,
            int slot,
            Item item,
            Component name,
            List<Component> lore,
            Runnable click) {
        GuiElementBuilder builder = new GuiElementBuilder(item).setName(name).setLoreRaw(lore);
        if (click != null)
            builder.setCallback(
                    (index, type, action, source) -> {
                        if (!controller.canUseMenus() && gui.page != Page.STATS) {
                            gui.getPlayer().sendSystemMessage(c("lobby_only"));
                            return;
                        }
                        click.run();
                    });
        gui.setSlot(slot, builder.build());
    }

    private static Component legacyName(String key, ChatFormatting color) {
        return Component.translatable(key)
                .withStyle(style -> style.withColor(color).withItalic(false));
    }

    private static ChatFormatting kitColor(String originalId) {
        return switch (originalId.charAt(0)) {
            case 'a' -> ChatFormatting.AQUA;
            case 'b' -> ChatFormatting.GOLD;
            case 'c' -> ChatFormatting.LIGHT_PURPLE;
            default -> ChatFormatting.RED;
        };
    }

    private static ChatFormatting skillColor(int index) {
        return switch (index) {
            case 0, 1, 2, 3 -> ChatFormatting.AQUA;
            case 4, 5, 6 -> ChatFormatting.GOLD;
            case 7, 8 -> ChatFormatting.LIGHT_PURPLE;
            case 11, 12 -> ChatFormatting.WHITE;
            default -> ChatFormatting.RED;
        };
    }

    private static List<Component> originalKitLore(List<String> keys) {
        List<Component> lore = new java.util.ArrayList<>();
        for (String key : keys) {
            lore.add(Component.translatable(key)
                    .withStyle(style -> style.withColor(ChatFormatting.GRAY).withItalic(false)));
        }
        return lore;
    }

    private static List<String> specialKitLoreKeys(int id) {
        return switch (id) {
            case 22 -> List.of("golden_pumpkin.lore");
            case 23 -> List.of("mace.lore.1", "mace.lore.2", "mace.lore.3", "mace.lore.4");
            case 24 -> List.of("wind_charge.lore");
            default -> List.of();
        };
    }

    private static List<String> originalKitLoreKeys(String id) {
        return switch (id) {
            case "a1" -> List.of("swrg.lore.kit.a1.0", "swrg.lore.kit.a1.1", "swrg.lore.kit.a1.2");
            case "a2" -> List.of("swrg.lore.kit.a2.0", "swrg.lore.kit.a2.1");
            case "a3" -> List.of("swrg.lore.kit.a3.0", "swrg.lore.kit.a3.1", "swrg.lore.kit.a3.2");
            case "a4" -> List.of("swrg.lore.kit.a4.0", "swrg.lore.kit.a4.1");
            case "a5" -> List.of("swrg.lore.kit.a5.0", "swrg.lore.kit.a5.1", "swrg.lore.kit.a5.2");
            case "a6" -> List.of("swrg.lore.kit.a6.0");
            case "a7" -> List.of("swrg.lore.kit.a7.0");
            case "b1" -> List.of("swrg.lore.kit.b1.0", "swrg.lore.kit.b1.1", "swrg.lore.kit.b1.2");
            case "b2" -> List.of("swrg.lore.kit.b2.0", "swrg.lore.kit.b2.1", "swrg.lore.kit.b2.2", "swrg.lore.kit.b2.3");
            case "b3" -> List.of("swrg.lore.kit.b3.0");
            case "b4" -> List.of("swrg.lore.kit.b4.0", "swrg.lore.kit.b4.1", "swrg.lore.kit.b4.2", "swrg.lore.kit.b4.3");
            case "b5" -> List.of("swrg.lore.kit.b5.0", "swrg.lore.kit.b5.1", "swrg.lore.kit.b5.2", "swrg.lore.kit.b5.3", "swrg.lore.kit.b5.4");
            case "c1" -> List.of("swrg.lore.kit.c1.0", "swrg.lore.kit.c1.1");
            case "c2" -> List.of("swrg.lore.kit.c2.0", "swrg.lore.kit.c2.1");
            case "c3" -> List.of("swrg.lore.kit.c3.0");
            case "c4" -> List.of("swrg.lore.kit.c4.0", "swrg.lore.kit.c4.1", "swrg.lore.kit.c4.2", "swrg.lore.kit.c4.3");
            case "c5" -> List.of("swrg.lore.kit.c5.0", "swrg.lore.kit.c5.1", "swrg.lore.kit.c5.2", "swrg.lore.kit.c5.3", "swrg.lore.kit.c5.4");
            case "d1" -> List.of("swrg.lore.kit.d1.0");
            case "d2" -> List.of("swrg.lore.kit.d2.0", "swrg.lore.kit.d2.1", "swrg.lore.kit.d2.2", "swrg.lore.kit.d2.3");
            case "d3" -> List.of("swrg.lore.kit.d3.0", "swrg.lore.kit.d3.1");
            default -> List.of();
        };
    }

    private static Component balance(int coins, int memcoins) {
        return Component.translatable("swrg.gui.balance")
                .withStyle(style -> style.withColor(ChatFormatting.WHITE).withItalic(false))
                .append(Component.literal(Integer.toString(coins)))
                .append(Component.literal(" "))
                .append(Component.translatable("swrg.gui.coins").withStyle(style -> style.withItalic(false)))
                .append(Component.literal(" / "))
                .append(Component.literal(Integer.toString(memcoins)))
                .append(Component.literal(" "))
                .append(Component.translatable("swrg.gui.memcoins").withStyle(style -> style.withItalic(false)));
    }

    private void back(Menu gui, int slot, ServerPlayer player, Page page) {
        putOriginalName(
                gui,
                slot,
                Items.ARROW,
                legacyName("swrg.gui.back", ChatFormatting.RED),
                List.of(c("back.lore")),
                true,
                () -> {
                    if (controller.canUseMenus()) open(player, page);
                    else player.closeContainer();
                });
    }

    private static void copyConfig(GameConfig from, GameConfig to) {
        to.lives = from.lives;
        to.health = from.health;
        to.countdownSeconds = from.countdownSeconds;
        to.stageOneSeconds = from.stageOneSeconds;
        to.stageTwoSeconds = from.stageTwoSeconds;
        to.endingSeconds = from.endingSeconds;
        to.stageOneEvent = from.stageOneEvent;
        to.stageTwoEvent = from.stageTwoEvent;
        to.pvpMode = from.pvpMode;
        to.day = from.day;
        to.vanillaKits = from.vanillaKits;
        to.vanillaSkills = from.vanillaSkills;
        to.noBorders = from.noBorders;
        to.mapId = from.mapId;
        to.broken = from.broken;
        to.save();
    }

    private static int cycle(int v, int min, int max) {
        return v >= max ? min : Math.max(min, v + 1);
    }

    private static int next(int v, int min, int max) {
        return cycle(v, min, max);
    }

    private static Component eventSelection(int n, String[] events) {
        if (n <= 0) return t("event.off");
        if (n == 1) return t("event.random");
        return t("event.selected", n - 1, t("event." + events[Math.min(n - 2, events.length - 1)]));
    }

    private static Component selected(int n) {
        return n == 0
                ? t("selection.none")
                : Component.translatable("skywars2.gui.selection.number", n);
    }

    private static Component selectedLabel(Component value) {
        return Component.translatable("swrg.gui.select")
                .withStyle(style -> style.withColor(ChatFormatting.GREEN).withItalic(false))
                .append(Component.literal(": "))
                .append(value);
    }

    private static Component yesNo(boolean b) {
        return b ? t("common.yes") : t("common.no");
    }

    private static Component join(int[] values) {
        return Component.translatable(
                "skywars2.gui.stats.keys.list",
                values[0],
                values[1],
                values[2],
                values[3],
                values[4]);
    }

    private static Component title(Page p, ServerPlayer player) {
        return switch (p) {
            case HUB -> t("hub.title");
            case SETTINGS -> legacyName("swrg.page0.s0", ChatFormatting.RED);
            case MAPS -> legacyName("swrg.page0.s2", ChatFormatting.AQUA);
            case VANILLA_KITS -> legacyName("swrg.page0.s12", ChatFormatting.GOLD);
            case VANILLA_SKILLS -> legacyName("swrg.page0.s14", ChatFormatting.AQUA);
            case KEY_SHOP -> legacyName("swrg.page0.s6", ChatFormatting.YELLOW);
            case STATS -> legacyName("swrg.stat.profile", ChatFormatting.GREEN).copy()
                    .append(Component.literal(player.getName().getString()));
            case LBC_KITS -> legacyName("swrg.page0.s22", ChatFormatting.WHITE);
            case LBC_SKILLS -> legacyName("swrg.page0.s23", ChatFormatting.WHITE);
            case LBC_TRINKETS -> t("lbc.trinkets");
            case LBC_LEVELUPS -> t("lbc.levelups");
            case LBC_CHALLENGE -> legacyName("swrg.page0.s24", ChatFormatting.WHITE);
            case COSMETICS -> legacyName("swrg.page0.s7", ChatFormatting.YELLOW);
            case CASES -> legacyName("swrg.page0.s13", ChatFormatting.LIGHT_PURPLE);
            case BEDWARS -> t("bedwars.title");
        };
    }

    private static Component lbcCategoryTitle(Page page) {
        return switch (page) {
            case LBC_KITS -> legacyName("swrg.page0.s22", ChatFormatting.WHITE);
            case LBC_SKILLS -> legacyName("swrg.page0.s23", ChatFormatting.WHITE);
            case LBC_CHALLENGE -> legacyName("swrg.page0.s24", ChatFormatting.WHITE);
            case LBC_TRINKETS -> t("lbc.trinkets");
            case LBC_LEVELUPS -> t("lbc.levelups");
            default -> throw new IllegalArgumentException("Not an LBC selector page: " + page);
        };
    }

    public enum Page {
        HUB,
        SETTINGS,
        MAPS,
        VANILLA_KITS,
        VANILLA_SKILLS,
        KEY_SHOP,
        STATS,
        LBC_KITS,
        LBC_SKILLS,
        LBC_TRINKETS,
        LBC_LEVELUPS,
        LBC_CHALLENGE,
        COSMETICS,
        CASES,
        BEDWARS
    }

    private static final class Menu extends SimpleGui {
        private final Page page;

        private Menu(ServerPlayer player, Page page) {
            super(MenuType.GENERIC_9x6, player, false);
            this.page = page;
        }
    }
}
